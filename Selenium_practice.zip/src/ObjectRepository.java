
public class ObjectRepository {
	
	final static String search = "//input[@name='q']";
	final static String button = "//button[@type='submit']";
    final static String all_links="//a[@class='top-list-item__link']";
};
