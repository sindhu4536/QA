package SpringDependency;

public class MyApplication {
	/*This class is responsible for initializing the EmailService and use it.This lead
	 * to hard code dependency*/
	private EmailService email = new EmailService();
	public void processingMessage(String mes,String rec){
		this.email.sendEmail(mes,rec);
	}

}
