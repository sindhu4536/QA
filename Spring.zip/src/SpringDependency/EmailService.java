package SpringDependency;
/*This class holds the logic of sending the mail to 
 * particular receiver*/

public class EmailService {
	
	public void sendEmail(String message,String receiver){
		System.out.println("message sent to "+receiver +" with message "+message);
		}

}
