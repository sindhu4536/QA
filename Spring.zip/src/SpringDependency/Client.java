package SpringDependency;

public class Client {
	public static void main(String args[] ){
		MyApplication myApplication = new MyApplication();
		myApplication.processingMessage("Hi Sindhu!", "surasindhuja@gmail.com");
		
	}

}
