
public class MethodDemo {

	static {
		System.out.println("Static block has highest priority than main block");
	}

	/*
	 * we can write a java program without main static{
	 * System.out.println("static block");
	 * 
	 * System.exit(0); }
	 */

	public static void main(String args[]) {
		MethodNumbers sum = new MethodNumbers();
		MethodNumbers product = new MethodNumbers(5, 11);
		MethodNumbers remainder = new MethodNumbers();
		MethodNumbers obj1 = new MethodNumbers();
		MethodNumbers obj2 = new MethodNumbers();
		++obj1.x;
		obj1.display(); // separate copies of instance variables are available
						// to objects
		obj2.display();

		++obj1.y;
		obj1.display1();// only one copy of static variable is available to
						// object
		obj2.display1();

		sum.sum();
		int result = product.product();
		System.out.println("product:" + result);
		int remainderresult = remainder.remainder(22, 4);
		System.out.println("remainderresult:" + remainderresult);
		float floatsum = MethodNumbers.floatSum(2, 4);
		System.out.println("floatsum:" + floatsum);

	}

}// objects are created for MethodNumbers class
