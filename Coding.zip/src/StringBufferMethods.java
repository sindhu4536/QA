
public class StringBufferMethods {
	
	public static void main(String args[])
	{
		/*String buffer class objects are mutable and default capacity of
		 * string buffer class objects are 16 characters*/
		
		/*String builder class objects are also mutable*/
		
		/* string buffer class is synchronized compared to string builder
		 * in case of multiple threads string buffer is used and in case of single thread
		 * string builder is used to improve execution time*/
		
		StringBuffer sb = new StringBuffer("Sindhuja");
		sb.append("sura");
		int n = sb.length();
		System.out.println("length of sb:"+n);
		
		sb.insert(12,"umkc");
		System.out.println("String after isertion:"+sb);
		int a = sb.indexOf("in");
		int b = sb.lastIndexOf("a");
		
		System.out.println("index of in:"+a);
		System.out.println("last index of:"+b);
		StringBuffer s= sb.reverse();
		System.out.println("reversed string:"+s);
		sb.delete(13, 16);
		StringBuffer s2 = new StringBuffer("Sindhuja");
		s2.replace(0, 8, "Sindhu");
		String c = s2.substring(0,4);
		System.out.println("Extracted string:"+c);
		
		
		
		
	}

}
