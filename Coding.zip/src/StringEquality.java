
public class StringEquality {

	public static void main(String args[])
	{
		String s1 = "Hello";
		String s2 = new String("Hello");
		String s3 = "Hello";
		
		if(s1==s2)
			System.out.println("Both are same");
		else
			System.out.println("not same");
		/* Here the object references of two string objects are compared
		 * object reference represents the memory address of the object created*/
		
		if(s1==s3)
			System.out.println("Both are same");
		else
			System.out.println("not same");
		/*String constant pool is the separate area held by JVM for string objects
		 * when s3 is created it checks the constant pool if there exist a string with same content
		 * if exist it creates another reference variable  and copies the refernec of the existing object
		 * */
		
		
	}
}
