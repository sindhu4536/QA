
public class First {

	
	int i = 12;
	
	protected  int b=5;
	
	First()
	{
		System.out.println("This is super class constructor");
	}
	
	First(int i)
	{
		this.i =i;
	}
	
	int calculate(int x)
	{
		return (x*x);
	}
	
	void display()
	{
		System.out.println("value of i:"+i);
	}
}
