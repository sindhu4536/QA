
public class Controls {
	
	public static void main(String args[])
	{
		// for
		for(int n=1;n<=10;n++)
		{
			System.out.println(n);
		}
		// nested for
		for(int i=1;i<=5;i++)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print("*");
				
			}
			System.out.println();
		}
		//do while
		int x=11;
		do
		{
			System.out.println(x);
			x++;
			
		}while(x<=20);
		// while loop
		int y=21;
		while(y<=30)
		{
			System.out.println(y);
			y++;
			
		}
	}
	}
	