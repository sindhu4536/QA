import java.io.*;

public class Input {
	public static void main(String args[])throws IOException
	{
		InputStreamReader obj = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(obj);
		
		System.out.println("Enter your name:");
		String name = br.readLine();
		
		System.out.println("Enter your sex:");
		char sex =(char)br.read();
		br.skip(2);// solution 1
		//char sex = br.readLine().charAt(0);
		/*
		 When we give a value for sex and press enter it releases a /n character which is 
		 allocated to ID so there arise an exception number format exception*/
		System.out.println("Enter your  Id:");
		int id = Integer.parseInt(br.readLine());
		
		System.out.println("Employee Details");
		
		
				System.out.println("Name:"+name);
				System.out.println("sex:"+sex);
                System.out.println("id:"+id);
                
               
		
		
		
	}

}
