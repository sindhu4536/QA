import java.io.*;
import java.util.*;// for using StringTokenizer class

public class InputMethod {
	
	public static void main(String args[])throws IOException
	{
		InputStreamReader obj = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(obj);
		System.out.println("Enter employee name,sex,id and year:");
		String st = br.readLine();
		StringTokenizer str = new StringTokenizer(st,",");
		// , is used as delimiter to accept different types of input in a sigle statement
		
		String s1 = str.nextToken();
		String s2 = str.nextToken();
		String s3 = str.nextToken();
		String s4 = str.nextToken();
		
		// to remove extra spaces before and after string
		s1 = s1.trim();
		s2 = s2.trim();
		s3 = s3.trim();
		s4 = s4.trim();
		
		String name = s1;
		String sex = s2;// a single character can be considered as string
		int id = Integer.parseInt(s3);
		int year= Integer.parseInt(s4);
		
		
		System.out.println("Employee details:");
		System.out.println("Employee name:"+name);
		System.out.println("Employee sex:"+sex);
		System.out.println("Employee id:"+id);
		
		// to test a given year is leap year or not century and non-century case
		
		if((year%100==0 && year%400==0) || (year%100 != 0 && year%4 == 0))
	
			System.out.println("Leap year");
		else
			System.out.println("not a leap year");
		
			
		
		
		
		
		
		
		
		
		
		
	}

}
