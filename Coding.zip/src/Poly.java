/*Polymorphism: Dynamic polymorphism and static polymorphism
 * DP occurs at run time and SP occurs at compile time
 * Method overloading:Two or more method having same name but difference in method 
 * signature
 * JVM recognizes the method by observing the method signature  
 * 
 * method overloading and overriding by static,final and private methods is called static polymorphism*/
public class Poly {
	
	void add(int a,int b)
	{
		System.out.println("sum:"+(a+b));
	}
	
	void add(int a,int b,int c)
	{
		System.out.println("sum:"+(a+b+c));
	}
	
	public static void main(String args[])
	{
		Poly p = new Poly();
		p.add(5, 4);
		p.add(3, 4,5);
	}

}
