
/*OOPS concepts
 * 1.class/objects: class does not exist physically and object exist physically
 * 2. Encapsulation: isolates members of class(variables(private) and methods(public) from 
 * other class members
 * 3. Abstraction: providing only the necessary data
 * 4.Inheritance:provides re-usability of code i.e parent and child class
 * 5.Polymorphism:A method can perform different activities */


/*constructor is used to initialize instance variables
 * name of a constructor is name of the class
 * there are two types of constructors:default and parameterized constructors
 * Constructor does not return any value
 *constructor is called and executed only once per object,constructor is called 
 *concurrently while the object creation is going on
 *writing two or more constructors with same name but difference in parameters is called
 *constructor overloading*/



public class Object1 {
	
	String name;
	int age;
	Object1()//default constructor
	{
		//name = "Sindhuja Sura";
		//age = 23;
		this("sindhuja sura", 24);// demo of use of "this" keyword
		
		this.details();
		
	}
	Object1(String s,int i)//parameterized constructor
	{
		this.name = s;
		this.age = i;
	}
	void details()
	{
		System.out.println("Name and age:"+name+","+age);
		
	}
	
	}
// objects for this class will be created in demo class
