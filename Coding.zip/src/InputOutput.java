import java.util.*;
public class InputOutput {
	
	public static void main(String args[])
	{
		System.out.printf("Enter name,id and salary:");
		Scanner sc = new Scanner(System.in);
		
		String name = sc.next();
		int id = sc.nextInt();
		float salary = sc.nextFloat();
		
		System.out.printf("Employee details: %n");
		
		System.out.printf("name :%s%n",name);
		System.out.printf("id :%d%n",id);
		System.out.printf("salary :%f%n",salary);
		sc.close();
	}

}
