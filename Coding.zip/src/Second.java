/*If we create a object to super class we can access only super class members
 * if we create object to sub class we can access both super class and sub class members
 * when a object for sub class is created it first calls all the super class constructors and 
 * then the sub class constructor
 * Private members of super class are not available directly for sub class for this purpose proteced 
 * specifier should be used 
 *   
 *   Writing two or more methods in the same class in such a way that methods have same name and 
 *   same signature it is called method overriding in this case JVM calls only the sub class method
 *   and never calls the super class method*/
public class Second extends First{
	
	int i = 20;
	
	Second()
	{
		System.out.println("This is sub class constructor");
	}
	
	Second(int a ,int b)
	{
	   super(a);// call super class constructor and pass a
		i=b;
	}
	
	 int calculate(int x)
	{
		return (x*x*x);
	}
	
	void display()
	{
		System.out.println("value of i:"+i);
		
		super.display();// to access the members of super class we need to use the keyword super
		
		System.out.println("value of i in super class:"+super.i);
		
		System.out.println("value of b in super class:"+super.b);
	}

}
