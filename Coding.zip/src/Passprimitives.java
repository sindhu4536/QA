
public class Passprimitives {
	
	public static void main(String args[])
	{
		int num1 = 10,num2=20;
		System.out.println("Before swap numbers are:"+num1+","+num2);
		Check c = new Check();
		
		c.swap(num1,num2);
		System.out.println("After swap numbers are:"+num1+","+num2);
		
		
	}

}
/* when primitive data types/objects/object references are passed to methods  only copy of their values will be
 *  send to objects,any modification done to those values inside method does not affect their original 
 *  values outside the method
 */