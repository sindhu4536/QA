
public class Demo {

	public static void main(String args[])
	{
		Object1 sindhu = new Object1();
		Object1 mounika = new Object1("sura mounika",20);
		
		System.out.println("hashcode of sindhu:"+sindhu.hashCode());
		System.out.println("hashcode of sindhu:"+mounika.hashCode());
		
		/*sindhu.name="sindhuja sura";
		sindhu.age= 23;*/
		System.out.println("details of sindhu:");
		sindhu.details();
		/*mounika.name="sura mounika";
		mounika.age = 20;*/
		System.out.println("details of mounika:");
		mounika.details();
		
	}
	
}
