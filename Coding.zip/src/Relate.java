
public class Relate {
	
	public static void main(String args[])
	{
		Three th = new Three();
		Two t =new Two(th);
		One o = new One(t);
		
		double result1 = o.cube(5);
		
		System.out.println("cube:"+result1);
		
		double result2 = t.square(5);
		
		System.out.println("square:"+result2);
	}

}

/*three ways to relate objects:
 * 1.using references
 * 2. using inner class concept
 * 3.using inheritance
 * */
