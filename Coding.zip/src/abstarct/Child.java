package abstarct;

public class Child implements Father,Mother{
	
	public void height()
	{
		float h = (Father.h + Mother.h)/2;
		System.out.println("Height of child:"+h);
	}
	
	

}
