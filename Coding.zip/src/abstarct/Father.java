package abstarct;

public interface Father {
	
	float h = 6.2f;
	void height();

}
