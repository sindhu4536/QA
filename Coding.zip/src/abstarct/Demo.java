package abstarct;

/*An interface have method prototypes,an interface consist of zero or more abstract methods
 * An interface have variables which are static public and final by default
 * none of the methods in interface can be private,protected or static
 * We cannot create object to interface but we can create a reference of interface type
 * An interface ca extend other interface but an interface cannot implement other interface*/
public class Demo {
	
	public static void main(String args[])
	{
		
		MyClass m;
		Sub1 s1 = new Sub1();
		Sub2 s2 = new Sub2();
		Sub3 s3 = new Sub3();
		
		m=s1;
		//m=s2;
		//m=s3;
		
		
		s1.calculate(4);
		s2.calculate(25);
		s3.calculate(2);
		m.calculate(7);
	}

}
