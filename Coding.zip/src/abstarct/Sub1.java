package abstarct;

public class Sub1 extends MyClass {
	
	void calculate(int x)
	{
		System.out.println("square:"+(x*x));
	}

}
