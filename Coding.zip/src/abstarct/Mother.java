package abstarct;

public interface Mother {
	
	float h = 5.8f;
	void height();
	

}
