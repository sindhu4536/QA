package abstarct;

//user should create an exception class as a subclass to exception class
// he can use parameterized constructor to store exception details,he can call super class constructor
//and pass the parameter
/*re- throwing exceptions is useful especially when the programmer wants to propagate the
 * exception details to other class*/

@SuppressWarnings("serial")
public class DefinedException extends Exception{
	
	private static String[] name = {"sindhu","sree","anu"};
	private static double bal[]= {1000000.00,999999.99,1111111.12};
	//default constructor
	DefinedException()
	{
		
	}
	//parameterized constructor
	DefinedException(String str)
	
	{
		super(str);
	}
 public static void main(String args[])
 {
	 try
	 {
		 System.out.println("name "+"\t"+"balance");
	     for(int i=0;i<3;i++)
	     {
	    	 System.out.println(name[i]+"\t"+bal[i]);
	  
	      if(bal[i]<=100000.00)
	      {
	    	 DefinedException de = new DefinedException("balance is less than one lakh");
	    	 throw de;
	      }
	     }
	 }
	catch(DefinedException de)
	 {
		de.printStackTrace();
	 }
 }
}
