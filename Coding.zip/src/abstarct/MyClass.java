
/*an abstract method does not have any method body.An abstract method is written when same method 
 * has to perform different task depending on the object calling it
 * 
 * An abstract class contains zero or more abstract methods and also contain concrete methods
 * 
 * We cannot create object to abstract class but we can create reference variable this does
 * not take any memory,reference can be used to refer sub class objects,the reference variable can access 
 * access only the features of sub class which have already been declared in super class
 *
 * 
 * abstract methods should be implemented in sub classes*/
package abstarct;

abstract public class MyClass {
	
	abstract void calculate(int x);
	

}
