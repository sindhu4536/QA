package abstarct;

public class Sub2 extends MyClass{
	
	void calculate(int x)
	{
		System.out.println("square root"+Math.sqrt(x));
	}


}
