package abstarct;

public class Sub3 extends MyClass{
	
	void calculate(int x)
	{
		System.out.println("cube:"+(x*x*x));
	}


}
