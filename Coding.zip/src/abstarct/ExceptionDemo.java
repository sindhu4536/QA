package abstarct;

import java.util.*;

/*throws clause is used to handle checked exceptions
 * throw clause is used to throw an exception explicitly and handle it*/

public class ExceptionDemo {

	public static void main(String args[]) {

		Scanner sc = new Scanner(System.in);

		/*
		 * statements where there are possibility of exceptions are stored in
		 * try block,even exceptions arise the program will not terminate when
		 * an exception arise it stores exception details in exception stack and
		 * jumps to catch block
		 */
		try {

			System.out.println("Enter the value:");

			//int n = sc.nextInt();

			int b[] = { 10, 2, 3 };
			b[20] = 100;

		}

		// exception details are displayed in this block
		catch (ArithmeticException ae) {
			System.out.println(ae);
		} catch (ArrayIndexOutOfBoundsException aie) {
			System.out.println(aie);
		}
		/*
		 * Even if there is scope for multiple exceptions only one exception at
		 * a time will occur
		 */
		finally {
			System.out.println("got the exception");
		}

		sc.close();

	}

}
