
public class Cast {
	
	public static void main(String args[])
	{
		// class and array are referred as referenced data types
		One_1 O;// reference for super class
		 O =  new Two_2();// O is referring to sub class object this is called widening
		 //O.show1();
		 /* we cannot refer to show2 method of sub class
		 * In widening user can access super class methods but not sub class methods
		  * But if we override the methods then we can access sub class methods*/
		 
		 //Two_2 t;
		 //t = (Two_2) new One_1();
		// t.show1();
		 
		// t.show2();
		 /*In narrowing using super class object we cannot access any of the methods of 
		  * the super class or sub class*/
		 
		 Two_2 t = (Two_2)O;//converting super class reference to sub class reference
		 t.show1();
		 t.show2();
		/*sub class object can be used to access both super and sub class methods
		 * narrowing using sub class object provides 100 % functionality*/
	}

}
