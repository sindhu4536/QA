import java.io.*;

public class Palindrome {
	
	public static void main(String args[])throws IOException
	{
		InputStreamReader obj = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(obj);
		System.out.println("Enter a string:");
	
		String s = br.readLine();
		
		String temp =s;
		
		StringBuffer sb = new StringBuffer(s);
		
		sb.reverse();
		
		s = sb.toString();
		
		if(temp.equals(s))
		{
			System.out.println("Entered string is palindrome");
			
		}
		else
		{
			System.out.println("not  palindrome");
		}
		
	}

}
