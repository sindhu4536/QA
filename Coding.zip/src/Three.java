
public class Three {
	
	double get(double x)
	{
		return x;
	}

}
