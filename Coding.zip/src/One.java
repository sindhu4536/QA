
public class One {
	
	Two t;// class two reference
	
	One(Two t)
	{
		this.t=t;
	}
    
	double cube(double x)
	{
		double result = x * t.square(x);
		return result;
	}
}
