import java.util.*;
import java.io.*;
public class MatrixMultiplication {
	
	public static void main(String args[])throws IOException
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter rows and columns of first matrix:");
		int r1 = sc.nextInt();
		int c1 = sc.nextInt();
		
		System.out.println("enter rows and columns of second matrix:");
		int r2 = sc.nextInt();
		int c2 = sc.nextInt();
		
		int matrixA[][] = new int[r1][c1];
		int matrixB[][] = new int[r2][c2];
		int matrixC[][] = new int [r1][c2];
		int sum=0;
		
		
		System.out.println("Enter elements of first matrix:");
		for(int i=0;i<r1;i++)
		{
			for(int j=0;j<c1;j++)
			{
				matrixA[i][j] = sc.nextInt();
			}
		}
		
		System.out.println("Enter elements of second matrix:");
		for(int i=0;i<r2;i++)
		{
			for(int j=0;j<c2;j++)
			{
				matrixB[i][j] = sc.nextInt();
			}
		}
		
		if(c1!=r2)
		{
			System.out.println("Matrix multiplication is not possible");
			
		}
		else
		{
			
			
			for(int i=0;i<r1;i++)// row of first matrix
			{
				for(int j=0;j<c2;j++)/* multiplied with elements of coulmn 1 of second matrix*/
					
					{
						for(int k=0;k<r2;k++)
						{
							
					
						sum += matrixA[i][k]*matrixB[k][j];
						
					}
						matrixC[i][j] = sum;
						sum =0;
			        }
						
				
			}
		}
		
		System.out.println("Matrix Product:");
		for(int i=0;i<r1;i++)
		{
			for(int j=0;j<c2;j++)
			{
				System.out.print(matrixC[i][j]+" ");
			}
			System.out.print("\n");
		}
		sc.close();
	}

}


