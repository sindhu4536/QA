

public class StringMethods {

	public static void main(String args[])
	{
		String s1 = "Java Programming";// Different ways of declaring a string
		String s2 = new String("book");
	
		
		String s5 = "Java";
		String s6 = "Programming";
		String s15= " sindhu ";
		
		String s7 = s1.concat(s2);
		System.out.println("concatination of strings 1 and 2:"+s7);
		int n =s1.length();
		System.out.println("Length of string 1:"+n);
		int i=0;
        char a = s1.charAt(i);
        
        System.out.println("char at i:"+a);
		int x = s5.compareTo(s6);//other method compareToIgnoreCase compares the 
		                         // strings irrespective of case sensitivity
		/* if(x==0)
		 {
			 System.out.println("Strings are equal");
		 }
		 else if(x>0)
		 {
			 System.out.println("String s1 is greater than s2");
		 }
		 else if(x<0)
		 {
			 System.out.println("String s1 is smaller than s2");
		 }*/
		System.out.println("x:"+x);
		  boolean b = s1.equals(s2);// other method equalsIgnoreCase
		  if(b==true)
		  {
			  System.out.println("Strings are equal");
		  }
		  else
		  {
			  System.out.println("Strings are not equal");
		  }
		  
		  boolean c = s1.startsWith(s5);
		  if(c==true)
		  {
			  System.out.println("String s1 starts with s5");
		  }
		  else
		  {
			  System.out.println("String s1 does not start with s5");
		  }
			  
		  
		  boolean d = s1.endsWith(s6);
		  if(d==true)
		  {
			  System.out.println("String s1 ends with s6");
		  }
		  else
		  {
			  System.out.println("String s1 does not end with s6");
		  }
		  
		  int w = s1.indexOf(s5);
		  
		   System.out.println("index:"+w);
		  
           int y = s1.lastIndexOf(s6);
		  
		  System.out.println("lastindex:"+y);
		  
		  char ch1 ='J';
		  char ch2 = 'k';
		  String s8 = s1.replace(ch1,ch2);
		  System.out.println("replaced string:"+s8);
		  
		  int i1 =0;
		  int i2 =3;
		  String s9= s1.substring(i1,i2);// string at position at i2 is excluded
		  System.out.println("Extracted String:"+s9);
		  String s10 = s1.toLowerCase();
		  System.out.println("lowercase string:"+s10);
		  String s11 = s1.toUpperCase();
		  System.out.println("Uppercase string:"+s11);
		  String s12 = s15.trim();
		  System.out.println("trimmed string:"+s12);
		  
		  char arr[]=new char[10];//initialize the array 
		  s1.getChars(0,3,arr,0);
		  String s13= new String(arr);
		  System.out.println("retrieved array:"+s13);
		  String s14[] = s1.split(" ");
		  
		  for(int z=0;z<s14.length;z++)
		  {
			  System.out.println(s14[z]);
		  }
		  /*String objects are immutable.....string class methods does not modify the content 
		   * same string object....string class methods are final and cannot be overridden*/
		  
		  }
}
