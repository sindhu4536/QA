
public class Check {
	
	void swap(int num1,int num2)
	{
		int temp= num1;
		num1 = num2;
		num2 = temp;
		//System.out.println("After swap numbers are :"+num1+","+num2);
	}
	
	

}
