import java.io.*;

public class Array {
	
	public static void main(String args[])throws IOException
	{
		InputStreamReader obj = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(obj);
		System.out.println("Number of subjects:");
		int n = Integer.parseInt(br.readLine());
		int marks[] = new int[n];
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter marks:");
			marks[i]= Integer.parseInt(br.readLine());
			
		}
		
		int total =0;
		
		for(int i=0;i<n;i++)
		{
			total= total+marks[i];
			
		}
		
		float percent = (float)total/n;
		System.out.println("Percentage:"+percent);
		
		
	}

}
