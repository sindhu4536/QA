
public class Two_2 extends One_1 {
	
	void show2()
	{
		System.out.println("Sub class");
	}

	/*void show1()
	{
		System.out.println("Sub class");
	}*/

}
