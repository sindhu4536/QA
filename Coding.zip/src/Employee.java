/*Cloneable interface does not have any methods or variables.Such an interface is called 
 * marking interface or tagging interface*/
public class Employee implements Cloneable {
	
	int id;
	String name;
	
	Employee(int id,String name)
	{
		this.id = id;
		this.name = name;
	}
	
	void getData()
	{
		System.out.println("Id"+id);
		System.out.println("name"+name);
		
	}
	//clone method of object class
	public Object myClone()throws CloneNotSupportedException
	{
		return super.clone();
	}
	

}
