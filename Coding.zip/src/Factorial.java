import java.util.*;
public class Factorial {
	
	static int factorial(int num)
	{  
		
		int result;
		if(num==1)
		{
			return 1;
		}
			
		else
		{
			result = factorial(num-1)*num;
			return result;
		}
		
			
	}
public static void main(String args[])
{
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter a number:");
	int n = sc.nextInt();
	int a= factorial(n);
	System.out.println("Factorial of given number:"+a);
	sc.close();
}
}
