//import java.lang.*;
import java.io.*;


public class Operators {
	
	public static void main(String args[])throws IOException
	{
		//Arithmetic and Unary operators
		//IOException is used to handle insufficient memory or illegal characters
		InputStreamReader obj = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(obj);
		System.out.println("Enter number x:");
		int x= Integer.parseInt(br.readLine());
		System.out.println("Enter number y:");
		int y= Integer.parseInt(br.readLine());
		System.out.println("Enter number z:");
		int z= Integer.parseInt(br.readLine());
		System.out.println("Enter number w"+ ":");
		int w= Integer.parseInt(br.readLine());
		boolean a =true;
		boolean b = false;
		
		//We can use br.read() to accept a single character type element.
		
		System.out.println("Sum ="+(x+y));
		System.out.println("differene ="+(x-y));
		System.out.println("product ="+(x*y));
		System.out.println("quotient ="+(x/y));
		System.out.println("Remainder ="+(x%y));
		System.out.println("Bitwise |:"+(x|y));
		System.out.println("Bitwise &:"+(x&y));
		System.out.println("Bitwise ^:"+(x^y));
		System.out.println("right shift:"+(x>>2));
		System.out.println("left shift:"+(y<<2));
		
		
		System.out.println("PretIncrement ="+(++x));
		System.out.println("PostIncrement="+(z++));
		System.out.println("PreDecrement ="+(--y));
		System.out.println("PostDecrement="+(w--));
		System.out.println("Unary Minus="+(-x));
		System.out.println("boolean and="+(a&b));
		System.out.println("boolean or="+(a|b));
		System.out.println("not a="+(!a));
		
		if(x>=y && y<=x)
			System.out.println("x is greater");
		else
			System.out.println("y is greater");
		if(y>w || y==w || y<w)
			System.out.println("both are equal");
		if(x!=y)
			System.out.println("they are not equal");
		if(!(x==y))
			System.out.println("They are not equal");
		
			
			
		
	
		
		
		
		
		
		
	}

}
