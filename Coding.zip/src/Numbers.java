import java.util.*;
public class Numbers {
	
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Number of numbers:");
		
		int n =  sc.nextInt();
		
		System.out.println("Enter the numbers in ascending order:");
		
		int A[] = new int[n];
		
		int length = A.length;
		
		for(int i=0;i<= length-1;i++)
		{
			A[i] = sc.nextInt();
		}
		
		int B[] = new int[n];
		
		for(int j=0;j<=length-1;j++)
		{
			B[j]=j;
		}
		
		int C[] = new int[n];
		
		for(int k=0;k<=length-1;k++)
			
		{
			C[k] = A[B[k]]+ 10;
		}
		System.out.println("Elements of array A:");
		
		for(int i=0;i<=length-1;i++)
		{
			System.out.print(A[i]+" ");
		}
		
		System.out.print("\n");
		
        System.out.println("Elements of array C:");
		
		for(int i=0;i<=length-1;i++)
		{
			System.out.print(C[i]+" ");
		}
		
		System.out.print("\n");
		
		int i =0;
		int j =0;
		boolean found = false;
		
		while((i<=length-1) && (j<=length-1) && (found == false))
		
		{
			if(A[B[i]] == C[j])
			{
				found = true;
				System.out.println("found two numbers:"+B[i]+","+B[j]);
				
			}
			
			else if(A[B[i]]<C[j])
			{
				i = i+1;
				
			}
			else if(A[B[i]]>C[j])
			{
				j=j+1;
			}
			
		}
		sc.close();
	}

}
