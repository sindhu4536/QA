
public class MethodNumbers {
	
	int a,b;
	int x = 10;
	int y= 10;
	void display()
	{
		System.out.println("Display x:"+x);
	}
	void display1()
	{
		System.out.println("Display y:"+y);
	}
	
	
	
	MethodNumbers()
	{
		a= 2;
		b=3;
		
	}
	
	MethodNumbers(int x,int y)
	{
		a =x;
		b =y;
		
	}
	
	void sum()// method without parameter and no return type
	{
		 int sum = a+b;
		System.out.println("sum of numbers:"+sum);
	}
	
	int product()//method with a return type but no parameters
	{
		int res = a*b;
		//System.out.println("product of two numbers:"+res);
		return res;
	}
	
	int remainder(int c, int d)
	{
		int rem = c%d;
		//System.out.println("remainder:"+rem);
		return rem;
	}
    static float floatSum(float s1,float s2 )
    {
    	float add = s1+s2;
    	return add;
    }
}
