
public class Two {
	
	Three th;
	
	Two(Three th)
	{
		this.th = th;// initializing the reference
		
	}
	
	double square(double x)
	{
		double  result = x*th.get(x);
		
		
		return result;
	}

}
