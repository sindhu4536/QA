
public class CloneDemo {
	
	public static void main(String args[])throws CloneNotSupportedException
	{
		Employee e1 = new Employee(10,"sindhu");
		e1.getData();
		
		//create another object by creating e1myClone() method returns object of object class type
		//it should be converted into employee type
		Employee e2 = (Employee) e1.myClone();
		e2.getData();
		
	}

}
