
public class CommandLine {
	
	
	public static void main(String args[])
	{
	
		
		
		/* to send command line arguments select run configurations and program arguments 
		 * tab provide the command line arguments and run the program */
		String s1 = args[0];
		String s2 = args[1];
		int a = Integer.parseInt(s1);
		int b = Integer.parseInt(s2);
		
		System.out.println("Entered values are:"+a+","+b);
		
		int sum = 0;
		
		sum= a+b;
		
		System.out.println("Sum of given numbers"+sum);
		
		
		
	}

}
