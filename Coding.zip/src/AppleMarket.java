import java.io.*;
import java.util.*;

public class AppleMarket {

	public int profit(int B[], int S[], int start, int end, int m, int min,
			int max) {

		for (int i = start; i <= (int) (start + end / 2); i++) {
			if (B[i] < min)// to find the minimum buying price in the given
							// array(left part of array)
			{
				min = B[i];

			}

		}

		for (int j = (int) (start + end / 2); j <= end; j++) {
			if (S[j] > max)// to find the maximum buying price in given
							// array(right part of array)
			{
				max = S[j];

			}

		}

		m = max - min;
		return m;
	}

	public static void main(String args[]) throws IOException {
		InputStreamReader obj = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(obj);

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number of markets:");

		String str = br.readLine();
		int n = Integer.parseInt(str);

		// Initializing buying and selling price arrays

		int B[] = new int[n];

		int S[] = new int[n];

		System.out.println("enter the buying prices of apples:");

		for (int i = 0; i < n; i++) {
			B[i] = sc.nextInt();
		}

		System.out.println("enter the selling prices of apples:");

		for (int i = 0; i < n; i++) {
			S[i] = sc.nextInt();
		}

		AppleMarket aa = new AppleMarket();

		int m_1 = 0;
		int x = 100;
		int y = 0;

		int start = 0;
		int end = n - 1;
		int mid = (int) n / 2;

		int max_1 = aa.profit(B, S, start, end, m_1, x, y);

		System.out.println("profit on considering total array:" + max_1);

		int ml = 0;
		int xl = 100;
		int yl = 0;

		int max_2 = aa.profit(B, S, start, mid - 1, ml, xl, yl);

		System.out.println("profit on considering left sub array:" + max_2);

		int mr = 0;
		int xr = 100;
		int yr = 0;

		int max_3 = aa.profit(B, S, mid, end, mr, xr, yr);
		System.out.println("profit on considering right sub array:" + max_3);

		if (max_1 >= max_2 && max_1 >= max_3)
			System.out.println("Maximum Profit:" + max_1);

		else if (max_2 > max_3)
			System.out.println("Maximum profit:" + max_2);
		else
			System.out.println("Maximum profit:" + max_3);
		sc.close();

	}
}