import java.io.*;

public class InsertionSort {
	public static void main(String args[])throws IOException
	{
		InputStreamReader obj = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(obj);
		System.out.println("number of elements:");
		int n =Integer.parseInt(br.readLine());
		int numbers[] = new int[n];
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter numbers:");
			numbers[i] = Integer.parseInt(br.readLine());
			
		}
		/*
		 Logic of insertion sort is every element is compared with its preceding element i.e 
		 is if there are three elements in an array second element is compared with first element,
		 third element is compared with first and second element and corresponding swapping is done*/
		for(int x=1;x<n;x++)
		{
			int key = numbers[x];
			int j = x-1;
		    while(j>-1 && numbers[j]>key)
		    {
		    	numbers[j+1] = numbers[j];
		    	j= j-1;
		    	
		    }
		    
		    numbers[j+1]=key;
		   
		    
		
		
	}
		System.out.println("Sorted array is:");
		for(int k=0;k<numbers.length;k++)
		{
			System.out.println(numbers[k]);
		}

}
}