import java.io.*;

public class Fibonacci {
	
	public static void main(String args[])throws IOException
	{
		InputStreamReader obj = new InputStreamReader(System.in);
		BufferedReader br  = new BufferedReader(obj);
		
	    System.out.println("Enter a value:");
		
		int n = Integer.parseInt(br.readLine());
		
		int f1 = 0;
		int f2 = 1;
		int f3 = f1 + f2;
		 System.out.println(f1);
		 System.out.println(f2);
		 System.out.println(f3);
		 int count =3;
		 
		 int sum=1;
		 
		 while(count <= n)
	    {
		   
		   f1 = f2;
		   f2=f3;
		   f3 = f1+f2;
		   System.out.println(f3);
		   count++;
		   
		 
		 }
		 
		 for(int i= 1;i<=n;i++)
		 {
			 
				sum = sum *i; 
		 }
		 
		 System.out.println("factotrial of given number:"+ sum);
		
	}
	

}
