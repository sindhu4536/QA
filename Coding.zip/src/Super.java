/*
 * when static methods are overridden then JVM decides which method is 
 * to be executed depending on the reference type used to call the method
 * 
 * In case of private methods overriding is not possible because private
 * methods of super class are not available to sub class.If they have methods with same name 
 * they have there own separate copies
 * 
 * final methods cannot be overridden because they are not available to subclasses
 * only method overloading can be achieved using final methods  */
 
public class Super {
	
	public static void main(String args[])
	{
		//Second t = new Second(20,30);
		
		First t = new Second();// super class reference refers to sub class object
		
		t.display();
		
		int n =t.calculate(5);
		
		System.out.println("result:"+n);
		
	}

}
