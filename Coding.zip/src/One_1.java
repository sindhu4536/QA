
public class One_1 {

	
	void show1()
	{
		System.out.println("Super class");
	}
}
