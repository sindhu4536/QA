import java.io.*;
import java.util.*;

public class Matrix {
	public static void main(String args[])throws IOException
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number of rows and columns:");
		int r = sc.nextInt();
		int c = sc.nextInt();
		
		int matrix[][] = new int[r][c];
		
		System.out.println("Enter elements of matrix:");
		
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				matrix[i][j] =sc.nextInt();
			}
		}
		
		System.out.println("Transposed matrix:");
		
		for(int i=0;i<c;i++)
		{
			for(int j=0;j<r;j++)
			{
				System.out.print(matrix[j][i]+" ");
				
			}
			System.out.print("\n");
		}
		sc.close();
		
	}

}
